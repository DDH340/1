#ifndef __TIM_H 
#define __TIM_H   

void TIM3_Init(void);

#endif
	
